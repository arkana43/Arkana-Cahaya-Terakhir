# Arkana: Cahaya Terakhir
Versi Final Awal